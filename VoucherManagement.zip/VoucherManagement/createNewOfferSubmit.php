<?php
ini_set("display_errors",1);
include_once("includes/session.inc.php");
set_time_limit(0);

if($_POST['offerid'] > 0){
	$db->query("Update `offers` Set offer_name = '".$_POST['offerName']."'
										,offer_percentage = '".$_POST['offerPercentage']."'
										,modified_on = '".date('Y-m-d')."'
										,is_active = '".$_POST['isactive']."'
										Where offer_id ='".$_POST['offerid']."'");
	$m = urlencode("Offer Updated Successfully!!");	
}else{
	$db->query("INSERT INTO `offers`
           (offer_name
           ,offer_percentage
           ,created_on
           ,is_active
          )
     VALUES(
     		'".$_POST['offerName']."',
            '".$_POST['offerPercentage']."',
            '".date('Y-m-d')."',
            '".$_POST['isactive']."'
           )");
	$m = urlencode("Offer Added Successfully!!");	
}
$p = urlencode($homeURL.'/listOfOffers.php');
header("Location: ".$homeURL."/redirect.php?m=".$m."&p=".$p);
?>