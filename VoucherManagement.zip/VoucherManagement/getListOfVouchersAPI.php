<?php
ini_set("display_errors",1);
include_once("includes/session.inc.php");
set_time_limit(0);
$arrDiscount = array();
if(!isset($_GET['email'])){
	echo "Email is blank";
	exit();
}else{
	$rs_voucher = $db->query("Select V.voucher_id, V.voucher_code, V.offer_id from `voucher` as V
	INNER JOIN `offers` as O ON O.offer_id = V.offer_id
	INNER JOIN `recipient` as R ON R.recipient_id = V.recipient_id
	Where R.recipient_email = '".$_GET['email']."' and V.is_active = 'Y'");
	if($db->num_rows($rs_voucher) > 0){
		while($row_voucher = $db->fetch_assoc($rs_voucher)){
			$arrVoucher[$row_voucher['voucher_id']]['offername'] = $offerArray['Name'][$row_voucher['offer_id']];
			$arrVoucher[$row_voucher['voucher_id']]['code'] = $row_voucher['voucher_code'];
		}
		echo json_encode($arrVoucher);
	}else{
		echo "Email not found";
		exit();
	}
}
?>
