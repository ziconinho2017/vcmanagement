// JavaScript Document
var isCheckOption = false;
var grnSearch = '<div id="overlay">'+
					'</div>';
function showOverlayBack(callBk) {
		if(document.getElementById('overlayBk') == null) {
			$('#h').prepend('<div id="overlayBk"></div>');
		}
		var _docHeight = (document.height !== undefined) ? document.height : document.body.offsetHeight;
		var _docWidth = (document.width !== undefined) ? document.width : document.body.offsetWidth;
		var _winHeight = $(window).height();
		if(_winHeight > _docHeight) {
			_docHeight = _winHeight;
		}
		var _winWidth = $(window).width();
		if(_winWidth > _docWidth) {
			_docWidth = _winWidth;
		}
		$('#overlayBk').css({width:_docWidth+'px',height:_docHeight+'px'}).animate({opacity: 0.6}, 500);
		//alert(callBk);
		if(callBk != undefined) {
			eval(callBk);
		}
}

function hideOverlayBk(callBk) {
		$('#overlayBk').animate({opacity: 0}, 100, function(){
																$(this).css({width:'0',height:'0'});
																if(callBk != undefined) {
																	eval(callBk+'()');
																}
															 });
}

function overlayClose(callBk) {
		if(document.getElementById('overlayMsg') != null) {
			$('#overlayMsg').fadeOut('fast', function(){
												   hideOverlayBk(callBk); 
												   }).remove();
		} else if(document.getElementById('overlay') != null) {
			$('#overlay').fadeOut('fast', function(){
												   hideOverlayBk(callBk); 
												   }).remove();
		}
}