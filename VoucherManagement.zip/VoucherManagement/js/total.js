// JavaScript Document

function trim(str){
	var a = str.replace(/^\s+/, '');
	return a.replace(/\s+$/, '');
}


function submitForm() {
	var isValid = true;	

	$('input').each(
		 function() {
			var id = $(this).attr('id'); 
			var idArray = id.split('_');
			if(idArray[1] == 'num') {
				var val = $('#'+id).val();
				if(isNaN(val) || val < 0 || trim(val) == '') {
					isValid = false;
					$('#'+id).addClass('redBrd');
				} else {
					$('#'+id).removeClass('redBrd');
				}
			}
		 }			 
	 );
	
	$('input').each(
			 function() {
				var id = $(this).attr('id'); 
				var idArray = id.split('_');
				if(idArray[1] == 'ne') {
					var val = $('#'+id).val();
					if(val == '') {
						isValid = false;
						$('#'+id).addClass('redBrd');
					} else {
						$('#'+id).removeClass('redBrd');
					}
				}
			 }			 
	);			
	
	$('select').each(
			 function() {
				var id = $(this).attr('id'); 
				var idArray = id.split('_');
				if(idArray[1] == 'ne') {
					var val = $('#'+id).val();
					if(val == '') {
						isValid = false;
						$('#'+id).addClass('redBrd');
					} else {
						$('#'+id).removeClass('redBrd');
					}
				}
			 }			 
	);
	
	$('textarea').each(
			 function() {
				var id = $(this).attr('id'); 
				var idArray = id.split('_');
				if(idArray[1] == 'ne') {
					var val = $('#'+id).val();
					if(val == '') {
						isValid = false;
						$('#'+id).addClass('redBrd');
					} else {
						$('#'+id).removeClass('redBrd');
					}
				}
			 }			 
	);
	
	if(isValid == true) {
		//alert('submit');
		$('#mainForm').submit();
	} else {
		alert("Please check the form!");
	}
}


function showOverlayBack(callBk) {
		if(document.getElementById('overlayBk') == null) {
			$('#h').prepend('<div id="overlayBk"></div>');
		}
		var _docHeight = (document.height !== undefined) ? document.height : document.body.offsetHeight;
		var _docWidth = (document.width !== undefined) ? document.width : document.body.offsetWidth;
		var _winHeight = $(window).height();
		if(_winHeight > _docHeight) {
			_docHeight = _winHeight;
		}
		var _winWidth = $(window).width();
		if(_winWidth > _docWidth) {
			_docWidth = _winWidth;
		}
		$('#overlayBk').css({width:_docWidth+'px',height:_docHeight+'px'}).animate({opacity: 0.6}, 500);
		//alert(callBk);
		if(callBk != undefined) {
			eval(callBk);
		}
}

function hideOverlayBk(callBk) {
		$('#overlayBk').animate({opacity: 0}, 100, function(){
																$(this).css({width:'0',height:'0'});
																if(callBk != undefined) {
																	eval(callBk+'()');
																}
															 });
}

function overlayClose(callBk) {
		if(document.getElementById('overlayMsg') != null) {
			$('#overlayMsg').fadeOut('fast', function(){
												   hideOverlayBk(callBk); 
												   }).remove();
		} else if(document.getElementById('overlay') != null) {
			$('#overlay').fadeOut('fast', function(){
												   hideOverlayBk(callBk); 
												   }).remove();
		}
}


function adjustTable(tableNo, vYTableEmulator, vXTableEmulator, vTableBody, vScroll, vHeaderContainer, vFooterContainer, vYFakeScroll, vXFakeScroll) {
	var YtableEmulator = document.getElementById(vYTableEmulator+tableNo);
	var XtableEmulator = document.getElementById(vXTableEmulator+tableNo);
	var table = document.getElementById(vTableBody+tableNo);
	if(table != null){
		//alert(table.clientHeight);
		YtableEmulator.style.height = table.clientHeight == 0 ? "330px" : table.clientHeight + "px";
		//YtableEmulator.style.height = table.clientHeight == 0 ? "330px" : "3000px";
		XtableEmulator.style.width = table.clientWidth + "px";
	
		var scrollablePanel = document.getElementById(vScroll+tableNo);
		var headerContainer = document.getElementById(vHeaderContainer+tableNo);
		var footerContainer = document.getElementById(vFooterContainer+tableNo);
		var YfakeScrollablePanel = document.getElementById(vYFakeScroll+tableNo);
		var XfakeScrollablePanel = document.getElementById(vXFakeScroll+tableNo);
	
	
		YfakeScrollablePanel.style.top = headerContainer.clientHeight == 0 ? "34px" : headerContainer.clientHeight + "px";
		scrollablePanel.onscroll = function (e) {
			XfakeScrollablePanel.scrollTop = scrollablePanel.scrollTop;
		}
		YfakeScrollablePanel.onscroll = function (e) {
			scrollablePanel.scrollTop = YfakeScrollablePanel.scrollTop;
		}
		XfakeScrollablePanel.onscroll = function (e) {
			scrollablePanel.scrollLeft = XfakeScrollablePanel.scrollLeft;
			headerContainer.scrollLeft = XfakeScrollablePanel.scrollLeft;
			footerContainer.scrollLeft = XfakeScrollablePanel.scrollLeft;
		}
		scrollablePanel.onscroll = function (e) {
			XfakeScrollablePanel.scrollLeft = scrollablePanel.scrollLeft;
			headerContainer.scrollLeft = scrollablePanel.scrollLeft;
			footerContainer.scrollLeft = scrollablePanel.scrollLeft;
		}
		footerContainer.onscroll = function (e) {
			XfakeScrollablePanel.scrollLeft = footerContainer.scrollLeft;
			headerContainer.scrollLeft = footerContainer.scrollLeft;
			scrollablePanel.scrollLeft = footerContainer.scrollLeft;
		}
	}
}


function addRow() {
	num++;
	var t = trElm.replace(/#num#/g, num);	
	$('#emptyTr').before(t);
	
	switch(page) {
		case 'po':
			$('#item_'+num).combobox();
			$('#item_'+num).change(function() {
				itemSelect($(this).attr('id'));
			});
			$('#estate_'+num).combobox();
			$('#grade_'+num).combobox();
			$('#location_'+num).combobox();
			$("#expiryDate_"+num).datepicker({
					showWeek: true,
					firstDay: 1,
					minDate: 0, 
					dateFormat: "yy-mm-dd",
					changeMonth: true,
					changeYear: true
			});
			if($('#purchaseType').val() == 'EOUAL' || $('#purchaseType').val() == 'DOMAL') {
				var pDate = $('#promptDate').val();
			} else {
				var pDate = $('#purchaseDate').val();
			}
			if(pDate != '') {
				var expDate = new Date();
				var pA = pDate.split('-');
				expDate.setFullYear(pA[0],(pA[1]-1),pA[2]);
				expDate.setDate(expDate.getDate()+365);
				var y = expDate.getFullYear();
				var m = expDate.getMonth();
				var d = expDate.getDate();
				$("#expiryDate_"+num).val(y+'-'+(m+1)+'-'+d);
			}
			break;
		case 'chalaiReceive':
		case 'reclaimReceive':
			$('#item_'+num).combobox();
			break;
		
	}
	
	
	
	
	/*if(page != undefined && page == 'po') {
		$( "#item_"+num).combobox();
	}*/
	reSerialize();
	adjustTable('', 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');	
}

function reSerialize() {
	var tc = $('#table-body tr').length;
	var tc1 = $('#table-body .emptyTr').length;
	
	var count = tc - tc1;
	var i = 1;
	$('#table-body .sr').each(function() {
		if(i <= count) {
			$(this).text(i);
			i++;	
		}
	});
}

var fS = 0;
var maxHt;
var fSHt = '530px';
function fullScreen(tableNo) {
	if(tableNo == undefined) {
		tableNo = '';
	}
	if(fS == 0) {
		showOverlayBack();
		$('#fWrapper'+tableNo).removeClass('fWrapper').addClass('fWrapperFS');
		maxHt = $("#scroll"+tableNo).css('max-height');
		$("#scroll"+tableNo).css({'max-height':fSHt});
		$("#y-fake-scroll"+tableNo).css({'max-height':fSHt});
		adjustTable(tableNo, 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');	
		fS = 1;
	} else {
		$('#fWrapper'+tableNo).removeClass('fWrapperFS').addClass('fWrapper');
		$("#scroll"+tableNo).css({'max-height':maxHt});
		$("#y-fake-scroll"+tableNo).css({'max-height':maxHt});
		adjustTable(tableNo, 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');	
		hideOverlayBk();
		fS = 0;
	}
}

function fetchData() {
	//var 
	FreezeScreen('Processing....')
	$.ajax({
		url: 'ajax/dataPrepare.php',
		type: 'POST',
		dateType: 'text',
		data: $('#mainForm').serialize(),
		timeout: 50000,
		error: function(){
			alert('Error loading ');
			UnFreezeScreen();
		},
		success: function(res){
			UnFreezeScreen();
			var t = res.substr(0,5) ;
			//alert(t);
			if(t == 'ERROR') {
				jAlert(res); 
			} else {
				//if(id == undefined) {
					if(activeId == undefined) {
						$('#tBody').html(res);
					} else {
						$('#tBody_'+activeId).html(res);
					}
				/*} else {
					$('#'+id).html(res);
				}*/
				colResizeAgain(2);
				adjustTable('_0', 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');
				
				adjustTable('_selItem', 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');
				adjustTable('', 'y-table-emulator', 'x-table-emulator', 'table-body', 'scroll', 'header-container', 'footer-container', 'y-fake-scroll', 'x-fake-scroll');
				
			}
		}
	});
}


function resetTable(id) {
	$('#'+id+' .dataTr').remove();
	//$('#'+id+' .forCount').remove();
}

function checkQty() {
	var isValid = 1;
	var hasValue = 0;
	$('.dataTr').each(function() {
		var q = Number($(".qty", this).text());
		var t = trim($(".selectedQty", this).val());
		//alert(q + ' - ' + t);
		if(isNaN(t) || t == '' || t < 0) {
			$(".selectedQty", this).parent().parent().children().each(function() {
				$(this).addClass('redBk');
			});
			isValid = 0;
		} else {
			$(".selectedQty", this).parent().parent().children().each(function() {
				$(this).removeClass('redBk');
			});
			if(t > 0) {
				hasValue = 1;
				if(t > q) {
					$(".selectedQty", this).parent().parent().children().each(function() {
						$(this).addClass('redBk');
					});
					isValid = 0;
				}
				var uom = $(".selectedUOM", this).text();
				if(uom == 'BAG' && (t % 1) != 0) {
					$(".selectedQty", this).parent().parent().children().each(function() {
						$(this).addClass('redBk');
					});
					isValid = 0;
				}
			}
		}
	});
	if(hasValue == 0) {
		isValid = -1;
	}
	return isValid;
}



(function( $ ) {
		$.widget( "ui.combobox", {
			_create: function() {
				var input,
					self = this,
					select = this.element.hide(),
					selected = select.children( ":selected" ),
					value = selected.val() ? selected.text() : "",
					wrapper = this.wrapper = $( "<span>" )
						.addClass( "ui-combobox" )
						.insertAfter( select );

				input = $( "<input>" )
					.appendTo( wrapper )
					.val( value )
					.addClass( "ui-state-default ui-combobox-input" )
					.autocomplete({
						delay: 0,
						minLength: 0,
						source: function( request, response ) {
							var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
							response( select.children( "option" ).map(function() {
								var text = $( this ).text();
								if ( this.value && ( !request.term || matcher.test(text) ) )
									return {
										label: text.replace(
											new RegExp(
												"(?![^&;]+;)(?!<[^<>]*)(" +
												$.ui.autocomplete.escapeRegex(request.term) +
												")(?![^<>]*>)(?![^&;]+;)", "gi"
											), "<strong>$1</strong>" ),
										value: text,
										option: this
									};
							}) );
						},
						select: function( event, ui ) {
							ui.item.option.selected = true;
							self._trigger( "selected", event, {
								item: ui.item.option
							});
							select.trigger("change"); 
						},
						change: function( event, ui ) {
							if ( !ui.item ) {
								var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( $(this).val() ) + "$", "i" ),
									valid = false;
								select.children( "option" ).each(function() {
									if ( $( this ).text().match( matcher ) ) {
										this.selected = valid = true;
										return false;
									}
								});
								if ( !valid ) {
									// remove invalid value, as it didn't match anything
									$( this ).val( "" );
									select.val( "" );
									input.data( "autocomplete" ).term = "";
									return false;
								}
							}
						}
					})
					.addClass( "ui-widget ui-widget-content ui-corner-left" );

				input.data( "autocomplete" )._renderItem = function( ul, item ) {
					return $( "<li></li>" )
						.data( "item.autocomplete", item )
						.append( "<a>" + item.label + "</a>" )
						.appendTo( ul );
				};

				$( "<a>" )
					.attr( "tabIndex", -1 )
					.attr( "title", "Show All Items" )
					.appendTo( wrapper )
					.button({
						icons: {
							primary: "ui-icon-triangle-1-s"
						},
						text: false
					})
					.removeClass( "ui-corner-all" )
					.addClass( "ui-corner-right ui-combobox-toggle" )
					.click(function() {
						// close if already visible
						if ( input.autocomplete( "widget" ).is( ":visible" ) ) {
							input.autocomplete( "close" );
							return;
						}

						// work around a bug (likely same cause as #5265)
						$( this ).blur();

						// pass empty string as value to search for, displaying all results
						input.autocomplete( "search", "" );
						input.focus();
					});
			},

			destroy: function() {
				this.wrapper.remove();
				this.element.show();
				$.Widget.prototype.destroy.call( this );
			}
		});
	})( jQuery );


function setCookie(c_name,value,exdays) {
	var exdate=new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
	document.cookie=c_name + "=" + c_value;
}
function getCookie(c_name) {
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++) {
		x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
		y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
		x=x.replace(/^\s+|\s+$/g,"");
		if (x==c_name) {
			return unescape(y);
		}
	 }
}



function FreezeScreen(msg) {
      //scroll(0,0);
      var outerPane = document.getElementById('FreezePane');
      var innerPane = document.getElementById('InnerFreezePane');
      if (outerPane) outerPane.className = 'FreezePaneOn';
      if (innerPane) innerPane.innerHTML = msg;
	  
	  var _docHeight = (document.height !== undefined) ? document.height : document.body.offsetHeight;
		var _docWidth = (document.width !== undefined) ? document.width : document.body.offsetWidth;
		var _winHeight = $(window).height();
		if(_winHeight > _docHeight) {
			_docHeight = _winHeight;
		}
		var _winWidth = $(window).width();
		if(_winWidth > _docWidth) {
			_docWidth = _winWidth;
		}
	  $('#FreezePane').css({width:_docWidth+'px',height:_docHeight+'px'});
   }
   
function  UnFreezeScreen() {
	$('#FreezePane').removeClass('FreezePaneOn').addClass('FreezePaneOff');
	$('form').unbind('submit');
	$('form').preventDoubleSubmission();
	//alert(jQuery.data('form','submitted'));
	/*alert($('form').data('submitted'));
	if($('form').data('submitted') === true) {
		alert(1);
		$('form').data('submitted', false);
		alert($('form').data('submitted'));
	}*/
	//alert(jQuery.data('form','submitted'));
	//$('form').data('submitted', false);
}


function colResizeAgain(num) {
		var columns = $("#tableheader"+num).find("th");
		var c = 0;
		columns.each(function(){ 
			$(".tableBody"+num).children().eq(0).children().eq(c).css({"width":$(this).width() + "px"});
			$(".tableFooter"+num+" tbody").children().eq(0).children().eq(c).css({"width":$(this).width() + "px"});
			c++;
		});	
}


/*
jQuery(document).bind('keydown', 'alt+t', function (evt){
    $('li#mTea').trigger('hover'); 
    evt.stopPropagation( );  
    evt.preventDefault( );
    return false;
});*/