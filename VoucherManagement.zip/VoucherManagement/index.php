<?php 
include_once ('includes/header.inc.php');
$arrVoucher = array();
$arrRecipient = array();
$rs_voucher = $db->query("Select * from voucher");
$rs_recipient = $db->query("Select * from recipient");
$rs_offer = $db->query("Select * from offers");
?>
<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >  
	        <div id="page-inner">
	        <div class="row">
                    <div class="col-md-12">
					<div class="row">
					
                    <div class="col-md-6" id="divInput">
                        <h5><?php echo "Number Of Voucher - ".$db->num_rows($rs_voucher); ?></h5>
                        <h5><?php echo "Number Of Offers - ".$db->num_rows($rs_offer); ?></h5>
						<h5><?php echo "Number Of Recipients - ".$db->num_rows($rs_recipient); ?></h5>
                    </div>
                </div>
               	</div>
               </div> 
	        </div>
    	</div>
   </div>
</div>
<script type="text/javascript">
</script>
<?php 
include_once ('includes/footer.inc.php');
?>