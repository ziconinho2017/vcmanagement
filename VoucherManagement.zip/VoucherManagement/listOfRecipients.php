<?php 
include_once ('includes/header.inc.php');
?>
<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
         <div id="page-inner">
                <div class="row">
                    <div class="col-md-12" id="divInput" style="height:600px;overflow: auto;">
                        <h4>List of Recipients</h4>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="width:25%;">Recipient Name</th>
                                    <th style="width:25%;">Recipient Email</th>
                                    <th style="width:10%;">Status</th>
                                    <th style="width:20%;">Get Vouchers List</th>
                                    <th><a href="createNewRecipient.php">Add New Recipient</a></th>
                                </tr>
                            </thead>
                            <tbody id="tbodyInput">
                            	<?php 
                            		$strRecipient = "";
                            		$rs_recipient = $db->query("Select * from recipient order by recipient_id ASC");
                            		while($row_recipient = $db->fetch_assoc($rs_recipient)){
                            			$strRecipient.= "<tr>
                            						<td>".$row_recipient['recipient_name']."</td>
				                                    <td>".$row_recipient['recipient_email']."</td>
				                                    <td>".$row_recipient['is_active']."</td>
				                                    <td><a href=\"getListOfVouchers.php?id=".$row_recipient['recipient_id']."\">Get Voucher List</a></td>
				                                    <td><a href=\"createNewRecipient.php?id=".$row_recipient['recipient_id']."\">Edit</a></td>
                                					</tr>";
                            		}
                            		echo $strRecipient;
                            	?>
                            	
                            </tbody>
                        </table>
               		</div>
               </div>
    	</div>
   </div>
</div>
<?php 
include_once ('includes/footer.inc.php');
?>