<?php 
include_once ('includes/header.inc.php');
$recipientName = "";
$recipientEmail = "";
$isactive = "";
$id = 0;
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$rs_recipient = $db->query("Select * from recipient Where recipient_id='".$_GET['id']."'");
	$row_recipient = $db->fetch_assoc($rs_recipient);
	$recipientName = $row_recipient['recipient_name'];
	$recipientEmail = $row_recipient['recipient_email'];
	$isactive = $row_recipient['is_active'];
}
?>
<!-- /. NAV SIDE  -->
       <div id="page-wrapper" >
        <form action="createNewRecipientSubmit.php" method="post" id="mainform" name="mainform" enctype="multipart/form-data">
            <div id="page-inner">
            <div class="col-md-4" style="width:400px;">
	            <div class="form-group">
	                <label>Recipient Name:</label>
	                <input type="hidden" id="recipientid" name="recipientid" value="<?=$id?>"/>
	                <input type="text" id="recipientName" name="recipientName" class="form-control" value="<?=$recipientName?>"/>  
	            </div>
            </div>
            <div class="col-md-4" style="width:400px;">
	            <div class="form-group">
	                <label>Recipient Email:</label>
	                <input type="text" id="recipientEmail" name="recipientEmail" class="form-control" value="<?=$recipientEmail?>"/>  
	            </div>
            </div>
            <div class="col-md-4" style="width:200px;">
	            <div class="form-group">
	                <label>IsActive?:</label>
	                <select class="form-control" name="isactive" id="isactive">
	                <option value="">Select</option>
	                <option value="Y" <?php if($isactive=="Y") { echo ' selected="selected"'; }?>>Y</option>
	                <option value="N" <?php if($isactive=="N") { echo ' selected="selected"'; }?>>N</option>
                    </select>
	            </div>
            </div>
             <div style="width:50%;padding-left:20px">  
	             <div align="left">
	                <button type="button" class="btn btn-primary" id="btnAddOutput" onclick="checkForm()">SAVE</button>
	             </div>
             </div>  
    	</div>
    	</form>
   </div>
</div>
<script type="text/javascript">
var doPost;
function checkForm(){
	doPost = true;
	if($('#recipientName').val() == ''){
		$('#recipientName').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#recipientName').removeClass('redBdr');
	}
	if($('#recipientEmail').val() == ''){
		$('#recipientEmail').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (reg.test($('#recipientEmail').val()) == false) 
        {
            alert('Invalid Email Address');
            $('#recipientEmail').addClass('redBdr');
            doPost = false;
        }else{
			$('#recipientEmail').removeClass('redBdr');
        }
	}
	if($('#isactive').val() == ''){
		$('#isactive').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#isactive').removeClass('redBdr');
	}
	if(doPost){
			$('#mainform').submit();
	}
}
</script>
<?php 
include_once ('includes/footer.inc.php');
?>