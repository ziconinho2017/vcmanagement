<?php 
include_once ('includes/header.inc.php');
$offerName = "";
$offerPercentage = 0;
$isactive = "";
$id = 0;
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$rs_offer = $db->query("Select * from offers Where offer_id='".$_GET['id']."'");
	$row_offer = $db->fetch_assoc($rs_offer);
	$offerName = $row_offer['offer_name'];
	$offerPercentage = $row_offer['offer_percentage'];
	$isactive = $row_offer['is_active'];
}
?>
<!-- /. NAV SIDE  -->
       <div id="page-wrapper" >
        <form action="createNewOfferSubmit.php" method="post" id="mainform" name="mainform" enctype="multipart/form-data">
            <div id="page-inner">
            <div class="col-md-4" style="width:400px;">
	            <div class="form-group">
	                <label>Offer Name:</label>
	                <input type="hidden" id="offerid" name="offerid" value="<?=$id?>"/>
	                <input type="text" id="offerName" name="offerName" class="form-control" value="<?=$offerName?>"/>  
	            </div>
            </div>
            <div class="col-md-4" style="width:400px;">
	            <div class="form-group">
	                <label>Offer Percentage:</label>
	                <input type="text" id="offerPercentage" name="offerPercentage" class="form-control" value="<?=$offerPercentage?>" onkeypress="return isNumberKey(event)"/>  
	            </div>
            </div>
            <div class="col-md-4" style="width:200px;">
	            <div class="form-group">
	                <label>IsActive?:</label>
	                <select class="form-control" name="isactive" id="isactive">
	                <option value="">Select</option>
	                <option value="Y" <?php if($isactive=="Y") { echo ' selected="selected"'; }?>>Y</option>
	                <option value="N" <?php if($isactive=="N") { echo ' selected="selected"'; }?>>N</option>
                    </select>
	            </div>
            </div>
             <div style="width:50%;padding-left:20px">  
	             <div align="left">
	                <button type="button" class="btn btn-primary" id="btnAddOutput" onclick="checkForm()">SAVE</button>
	             </div>
             </div>  
    	</div>
    	</form>
   </div>
</div>
<script type="text/javascript">
var doPost;
function checkForm(){
	doPost = true;
	if($('#offerName').val() == ''){
		$('#offerName').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#offerName').removeClass('redBdr');
	}
	if($('#offerPercentage').val() == ''){
		$('#offerPercentage').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#offerPercentage').removeClass('redBdr');
	}
	if($('#isactive').val() == ''){
		$('#isactive').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#isactive').removeClass('redBdr');
	}
	if(doPost){
			$('#mainform').submit();
	}
}
function isNumberKey(evt)
{
   var charCode = (evt.which) ? evt.which : evt.keyCode;
   if (charCode != 46 && charCode > 31 
     && (charCode < 48 || charCode > 57))
      return false;

   return true;
}
</script>
<?php 
include_once ('includes/footer.inc.php');
?>