<?php
ini_set("display_errors",1);
include_once("includes/session.inc.php");
set_time_limit(0);

if($_POST['recipientid'] > 0){
	$db->query("Update `recipient` Set recipient_name = '".$_POST['recipientName']."'
										,recipient_email = '".$_POST['recipientEmail']."'
										,modified_on = '".date('Y-m-d')."'
										,is_active = '".$_POST['isactive']."'
										Where recipient_id ='".$_POST['recipientid']."'");
	$m = urlencode("Recipient Updated Successfully!!");	
}else{
	$rs_email = $db->query("Select * from `recipient` Where recipient_email = '".$_POST['recipientEmail']."'");
	if($db->num_rows($rs_email) > 0){
		$m = urlencode("Duplicate Email Address!!");
	}else{
		$db->query("INSERT INTO `recipient`
	           (recipient_name
	           ,recipient_email
	           ,created_on
	           ,is_active
	          )
	     VALUES(
	     		'".$_POST['recipientName']."',
	            '".$_POST['recipientEmail']."',
	            '".date('Y-m-d')."',
	            '".$_POST['isactive']."'
	           )");
		$m = urlencode("Recipient Added Successfully!!");	
	}
}
$p = urlencode($homeURL.'/listOfRecipients.php');
header("Location: ".$homeURL."/redirect.php?m=".$m."&p=".$p);
?>