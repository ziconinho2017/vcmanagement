<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Redirecting...</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php
if($_GET['r'] != 'f') {
?>
<meta http-equiv="refresh" content="3;url=<?=$_GET['p']?>">
<?php
}
?>
</head>

<body style="text-align:center; padding-top: 100px">
<div style="width:100%; background-color:white; color:#5a6b34; padding:10px 0; border-top: 10px solid #95ccff;  border-bottom: 10px solid #95ccff;">

	<h3 style="font-size:20px">...<?=$_GET['m']?>...</h3>
	<img src="assets/img/redirect.gif" width="40px" style="padding:20px" />
	<p>If the page does not redirects automatically - <br /><a href="<?=$_GET['p']?>"><strong>Click Here</strong></a></p>
</div>	
</body>
</html>