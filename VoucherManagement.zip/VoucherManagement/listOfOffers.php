<?php 
include_once ('includes/header.inc.php');
?>
<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
         <div id="page-inner">
                <div class="row">
                    <div class="col-md-12" id="divInput" style="height:600px;overflow: auto;">
                        <h4>List of Offers</h4>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="width:30%;">Offer Name</th>
                                    <th style="width:30%;">Offer Percentage</th>
                                    <th style="width:20%;">Status</th>
                                    <th><a href="createNewOffer.php">Add New Offer</a></th>
                                </tr>
                            </thead>
                            <tbody id="tbodyInput">
                            	<?php 
                            		$strOffer = "";
                            		$rs_offer = $db->query("Select * from offers order by offer_id ASC");
                            		while($row_offer = $db->fetch_assoc($rs_offer)){
                            			$strOffer.= "<tr>
                            						<td>".$row_offer['offer_name']."</td>
				                                    <td>".$row_offer['offer_percentage']."</td>
				                                    <td>".$row_offer['is_active']."</td>
				                                    <td><a href=\"createNewOffer.php?id=".$row_offer['offer_id']."\">Edit</a></td>
                                					</tr>";
                            		}
                            		echo $strOffer;
                            	?>
                            	
                            </tbody>
                        </table>
               		</div>
               </div>
    	</div>
   </div>
</div>
<?php 
include_once ('includes/footer.inc.php');
?>