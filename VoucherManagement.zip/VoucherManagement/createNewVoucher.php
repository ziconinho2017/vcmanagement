<?php 
include_once ('includes/header.inc.php');
?>
<!-- /. NAV SIDE  -->
       <div id="page-wrapper" >
        <form action="createNewVoucherSubmit.php" method="post" id="mainform" name="mainform" enctype="multipart/form-data">
            <div id="page-inner">
            <div class="col-md-4" style="width:200px;">
	            <div class="form-group">
	                <label>Select Offer:</label>
	                <?php
	                if(count($offerArray) > 0){
						echo makeSelect('offerid', $offerArray['Name'], '', '', '', '', 'offerid', '','form-control');
	                }else{
	                	echo "There is no active offers.";
	                }
					?>
	            </div>
            </div>
            <div class="col-md-4" style="width:200px;">
	            <div class="form-group">
	                <label>Select Recipient:</label>
	                <?php
	                if(count($recipientArray['Name']) > 0){
						echo makeSelect('recipientid', $recipientArray['Name'], '', '', '', '', 'recipientid', '','form-control');
	                }else{
	                	echo "There is no active recipients.";
	                }
					?>
	            </div>
            </div>
            <div class="col-md-4" style="width:200px;">
	            <div class="form-group">
	                <label>Expiry Date:</label>
	                <input type="text" id="expiryDate" name="expiryDate" class="form-control" readonly="readonly"/>  
	            </div>
            </div>
             <div style="width:50%;padding-left:20px">  
	             <div align="left">
	                <button type="button" class="btn btn-primary" id="btnAddOutput" onclick="checkForm()">SAVE</button>
	             </div>
             </div>  
    	</div>
    	</form>
   </div>
</div>
<script type="text/javascript">
$( function() {
	$( "#expiryDate" ).datepicker({
		minDate:0, // yesterday is minimum date
    	maxDate:'+1970/01/02'
	});
    //formatTime:'H:i',
	//formatDate:'d.m.Y',
	//defaultDate:'8.12.1986',
	//defaultDate:'+03.01.1970',
	//defaultTime:'10:00',
	//timepickerScrollbar:false
    //inline:true
    //mask:'9999/19/39 29:59'
    //datepicker:false,
    //minDate:'-1970/01/2',
	//maxDate:'+1970/01/2',
    //disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
  } );
var doPost;
function checkForm(){
	doPost = true;
	if($('#offerid').val() == ''){
		$('#offerid').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#offerid').removeClass('redBdr');
	}
	if($('#expiryDate').val() == ''){
		$('#expiryDate').addClass('redBdr');
		doPost = false;
		return false;
	}else{
		$('#expiryDate').removeClass('redBdr');
	}
	if(doPost){
			$('#mainform').submit();
	}
}
</script>
<?php 
include_once ('includes/footer.inc.php');
?>