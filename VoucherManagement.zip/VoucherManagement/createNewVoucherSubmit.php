<?php
ini_set("display_errors",0);
include_once("includes/session.inc.php");
set_time_limit(0);
if($_POST['recipientid'] == ""){
	foreach ($recipientArray['Name'] as $kRecipient => $vRecipient){
		$len = rand(8,16);
		do {
		    $code = rand_code($len);
		    $q = $db->query("Select * from `voucher` Where voucher_code = '".$code."'");
		} while($db->num_rows($rs_voucher) > 0);
		$rs_query = $db->query("Select * from `voucher` Where offer_id = '".$_POST['offerid']."' and recipient_id ='".$kRecipient."'");
		if($db->num_rows($rs_query) > 0){
			echo "This offer is already assigned to ".$recipientArray['Email'][$kRecipient];
			exit();
		}else{
			$db->query("INSERT INTO `voucher`
		           (voucher_code
		           ,offer_id
		           ,recipient_id
		           ,created_on
		           ,expiry_date
		           ,is_active
	          		)
		     VALUES(
		     		'".$code."',
		            '".$_POST['offerid']."',
		            '".$kRecipient."',
		            '".date('Y-m-d')."',
		            '".date('Y-m-d',strtotime($_POST['expiryDate']))."',
		            'Y'
		           )");
		}
	}
	$m = urlencode("Voucher have been added for all recipients Successfully!!");
}else{
	$len = rand(8,16);
	do {
	    $code = rand_code($len);
	    $q = $db->query("Select * from `voucher` Where voucher_code = '".$code."'");
	} while($db->num_rows($rs_voucher) > 0);
	$rs_query = $db->query("Select * from `voucher` Where offer_id = '".$_POST['offerid']."' and recipient_id ='".$_POST['recipientid']."'");
		if($db->num_rows($rs_query) > 0){
			$m = urlencode("This offer is already assigned to ".$recipientArray['Email'][$_POST['recipientid']]);
			exit();
		}else{
		$db->query("INSERT INTO `voucher`
	           (voucher_code
	           ,offer_id
	           ,recipient_id
	           ,created_on
	           ,expiry_date
	           ,is_active
	          	)
	     VALUES(
	     		'".$code."',
	            '".$_POST['offerid']."',
	            '".$_POST['recipientid']."',
	            '".date('Y-m-d')."',
	            '".date('Y-m-d',strtotime($_POST['expiryDate']))."',
	            'Y'
	           )");
		$m = urlencode("Voucher have been added for ".$recipientArray['Name'][$_POST['recipientid']]." Successfully!!");
		}
	
}
$p = urlencode($homeURL.'/listOfVouchers.php');
header("Location: ".$homeURL."/redirect.php?m=".$m."&p=".$p);
?>