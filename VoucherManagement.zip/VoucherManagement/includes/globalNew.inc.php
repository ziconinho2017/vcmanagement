<?php
	$offerArray = array();
	$rs = $db->query("SELECT * FROM offers Where is_active = 'Y' ORDER BY offer_id ASC");
	while($row = $db->fetch_assoc($rs)) {
		$offerArray['Percentage'][$row['offer_id']] = $row['offer_percentage'];
		$offerArray['Name'][$row['offer_id']] = $row['offer_name'];
	}
	$recipientArray = array();
	$rs = $db->query("SELECT * FROM recipient Where is_active = 'Y' ORDER BY recipient_id ASC");
	while($row = $db->fetch_assoc($rs)) {
		$recipientArray['Email'][$row['recipient_id']] = $row['recipient_email'];
		$recipientArray['Name'][$row['recipient_id']] = $row['recipient_name'];
	}

	function makeSelect($name, $array, $default='', $selected='', $width=90, $multiple=0, $id='', $action='', $class='', &$nameA='') {
		/*echo '<pre>';
		print_r($array);
		echo '</pre>';*/
		$str = '<select name="'.$name.'" id="'.(($id=='')?$name:$id).'" '.(($multiple==1)?' multiple="multiple"':'').(($action!='')?' onChange="'.$action.'"':'').' class="'.(($class=='')?'':$class).'">';
		if($default == -1) {
			$str .= '<option value="0">All</option>';	
		} else {
			$str .= '<option value="'.$default.'">select</option>';	
		} 
			
		foreach($array as $k=>$v) {
			$str .= '<option value="'.$k.'"'.(($selected==$k)?' selected="selected"':'').'>'.$v.(($nameA!='')?' - '.$nameA[$k]:'').'</option>';
		}
		$str .= '</select>';
		return $str;
	}
function date_diff($fromdate,$todate){
	$diff = abs(strtotime($todate) - strtotime($fromdate));
	$years = floor($diff / (365*60*60*24));
	$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
	$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
	return $days;
}

function rand_code($len)
{
	$min_lenght= 7;
	$max_lenght = 16;
	$bigL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$smallL = "abcdefghijklmnopqrstuvwxyz";
	$number = "0123456789";
	$bigB = str_shuffle($bigL);
	$smallS = str_shuffle($smallL);
	$numberS = str_shuffle($number);
	$subA = substr($bigB,0,5);
	$subB = substr($bigB,6,5);
	$subC = substr($bigB,10,5);
	$subD = substr($smallS,0,5);
	$subE = substr($smallS,6,5);
	$subF = substr($smallS,10,5);
	$subG = substr($numberS,0,5);
	$subH = substr($numberS,6,5);
	$subI = substr($numberS,10,5);
	$RandCode1 = str_shuffle($subA.$subD.$subB.$subF.$subC.$subE);
	$RandCode2 = str_shuffle($RandCode1);
	$RandCode = $RandCode1.$RandCode2;
	if ($len>$min_lenght && $len<$max_lenght)
	{
		$CodeEX = substr($RandCode,0,$len);
	}
	else
	{
		$CodeEX = $RandCode;
	}
	return $CodeEX;
}
?>