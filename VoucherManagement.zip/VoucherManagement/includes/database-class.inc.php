<?php

class db {// db.class.php, Database connection / query functions.
	var $hostname;// Hostname that the object should connect to
	var $username;// Username that the object should use
	var $password;// Password that the object should use
	var $database;// Database that the object should use
	var $query_num;// counts the total queries that the object has done. Some BBs do this. Might be of use for optimization etc
				
	function set_cred($hostname,$username,$password) {
			 $this->hostname = $hostname;
			 $this->username = $username;
			 $this->password = $password;
	}
	
	function db_connect() {
		$result = mysql_connect($this->hostname, $this->username, $this->password);
		/*
		Open a persistant connection to the server. Same as mysql_connect with CGI
		Because PHP has to be spawned each time anyway.
		*/
		if (!$result) {
			echo 'Connection to database server at: '.$this->hostname.' failed.';
			
return false;
		}
													
		return $result;
	}
				

	function db_pconnect() {
		$result = mysql_pconnect($this->hostname, $this->username, $this->password);
		/*
		Open a persistant connection to the server. Same as mysql_connect with CGI
		Because PHP has to be spawned each time anyway.
		*/
		if (!$result) {
			echo 'Connection to database server at: '.$this->hostname.' failed.';
			
return false;
		}
													
		return $result;
	}

	function select_db($database) {
		$this->database = $database;
		if (!mysql_select_db($this->database)) {
			echo 'Selection of database: '.$this->database.' failed.';
			
return false;
		}
	}
				
	function query($query) {
		$result = mysql_query($query) or die("Query failed: $query<br><br>   ----     ".$query);
		return $result;
	}
	
	function masterQuery($query) {
		$result = mysql_query($query) or die("<strong style=\"color:red\">Duplicate Entry!!</strong><br />Press back button of browser.");
		return $result;
	}
				
	function fetch_array(&$result) {
		return mysql_fetch_array($result);
	}
	
	function fetch_assoc(&$result) {
		return mysql_fetch_assoc($result);
	}
	
	function return_query_num() {
		return $this->query_num;
	}
	
	function num_rows($result) {
		return mysql_num_rows($result);
	}
	
	function free_result($result) {
		mysql_free_result($result);
	}
		
	function data_seek(&$result,$row_number) {
		mysql_data_seek($result,$row_number);
	}
	
	function do_filter($str) {
		$str = str_replace("|", " ", $str);
		if(get_magic_quotes_gpc() == 1) {
			return $str;
		} else {
			return addslashes($str);
		}
	}
};

?>
