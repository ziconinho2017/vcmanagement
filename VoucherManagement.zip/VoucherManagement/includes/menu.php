<nav
	class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
	<li><a href="#"><i class="fa fa-edit "></i>Recipient<span
		class="fa arrow"></span></a>
	<ul class="nav nav-second-level">
		<li><a href="listOfRecipients.php">List Of Recipients</a></li>
		<li><a href="createNewRecipient.php">Add New Recipient</a></li>
	</ul>
	</li>
	<li><a href="#"><i class="fa fa-edit "></i>Offers<span
		class="fa arrow"></span></a>
	<ul class="nav nav-second-level">
		<li><a href="listOfOffers.php">List Of Offers</a></li>
		<li><a href="createNewOffer.php">Add New Offer</a></li>
	</ul>
	</li>
	<li><a href="#"><i class="fa fa-edit "></i>Vouchers<span
		class="fa arrow"></span></a>
	<ul class="nav nav-second-level">
		<li><a href="listOfVouchers.php">List Of Vouchers</a></li>
		<li><a href="createNewVoucher.php">Add New Voucher</a></li>
	</ul>
	</li>


	<!--  <li><a href="#"><i class="fa fa-sitemap "></i>Multi-Level Dropdown<span
		class="fa arrow"></span></a>
	<ul class="nav nav-second-level">
		<li><a href="#">Second Level Link</a></li>
		<li><a href="#">Second Level Link</a></li>
		<li><a href="#">Second Level Link<span class="fa arrow"></span></a>
		<ul class="nav nav-third-level">
			<li><a href="#">Third Level Link</a></li>
			<li><a href="#">Third Level Link</a></li>
			<li><a href="#">Third Level Link</a></li>

		</ul>

		</li>
	</ul>
	</li>-->
</ul>

</div>

</nav>
