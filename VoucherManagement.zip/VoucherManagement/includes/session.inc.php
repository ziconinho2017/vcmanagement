<?php
	if(!isset($ob)) {
		ob_start();
		session_start();	
	}
	$validSession = false;
	$permArray = array();
	//exit();
	include_once('constants.inc.php');
	include_once('database-class.inc.php');

	$db = new db();
	$db->set_cred($hostname,$username,$password);//set credentials ready to connect,
	$db->db_connect();// connect to the database using a non persistant connection
	$db->select_db($database); // Select database
	include_once('globalNew.inc.php');
?>