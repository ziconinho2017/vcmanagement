<?php
	include_once("session.inc.php");
	$jsStamp = time();
	if (strpos($_SERVER['PHP_SELF'], 'listOfRecipients.php') !== false) {
		$heading = "List Of Recipients";
	}elseif (strpos($_SERVER['PHP_SELF'], 'createNewRecipient.php') !== false) {
		$heading = "Add New Recipient";
	}elseif (strpos($_SERVER['PHP_SELF'], 'listOfOffers.php') !== false) {
		$heading = "List Of Offers";
	}elseif (strpos($_SERVER['PHP_SELF'], 'createNewOffer.php') !== false) {
		$heading = "Add New Offers";
	}elseif (strpos($_SERVER['PHP_SELF'], 'listOfVouchers.php') !== false) {
		$heading = "List Of Vouchers";
	}elseif (strpos($_SERVER['PHP_SELF'], 'createNewVoucher.php') !== false) {
		$heading = "Add New Voucher";
	}else{
		$heading = "Dashboard";
	}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Voucher Management</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href="css/font.css" rel='stylesheet'/>
   <link href="css/style.css" rel='stylesheet' />
   <link href="css/jquery-ui.css" rel='stylesheet'/>
   <link rel="stylesheet" type="text/css"  href="css/ui.dropdownchecklist.themeroller.css"/>
   <link href="assets/css/jquery.datetimepicker.css" rel='stylesheet'/>
   <script src="assets/js/jquery-1.12.4.js"></script>
   <script src="assets/js/smooth_scroll.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/ui.dropdownchecklist-1.4-min.js"></script>
    <script src="assets/js/jquery.datetimepicker.full.js"></script>
    <script src="js/js.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/total.js<?='?t='.$jsStamp?>"></script>
</head>
<body>
    <div align="center" id="FreezePane" class="FreezePaneOff">
  	 <div id="InnerFreezePane" class="InnerFreezePane"> </div>
	</div> 
           
          
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Voucher Management</a>
                    <a class="navbar-brand" href="#" style="margin:auto;"><?=$heading?></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li></li>
                    </ul>
                </div>

            </div>
        </div>
        <!-- /. NAV TOP  -->
        <?php include_once ("includes/menu.php");?>
        