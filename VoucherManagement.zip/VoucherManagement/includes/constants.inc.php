<?php
$hostname = 'localhost';//'192.168.10.68:8080';
$username = 'jai';
$password = 'OkcR3mHGikXZ4ChV';	
$database = "voucher";
$homeURL = 'http://localhost:8080/VoucherManagement';
/*$hostname = 'localhost';//'192.168.10.68:8080';
$username = 'jaytinfo_jai';
$password = 'OkcR3mHGikXZ4ChV';	
$database = "jaytinfo_gst_info";
$homeURL = 'http://jaytea.info/MJILVendorInformation/';*/
?>