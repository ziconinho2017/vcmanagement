<?php 
include_once ('includes/header.inc.php');
?>
<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
         <div id="page-inner">
                <div class="row">
                    <div class="col-md-12" id="divInput" style="height:600px;overflow: auto;">
                        <h4>List of Vouchers</h4>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="width:20%;">Offer Name</th>
                                    <th style="width:20%;">Voucher Code</th>
                                    <th style="width:20%;">Recipient Name</th>
                                    <th style="width:10%;">Expiry Date</th>
                                    <th style="width:10%;">Redeemed On</th>
                                    <th style="width:10%;">Status</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyInput">
                            	<?php 
                            		$strVoucher = "";
                            		$rs_voucher = $db->query("Select * from voucher order by voucher_id ASC");
                            		while($row_voucher = $db->fetch_assoc($rs_voucher)){
                            			$strOffer.= "<tr>
                            						<td>".$offerArray['Name'][$row_voucher['offer_id']]."</td>
				                                    <td>".$row_voucher['voucher_code']."</td>
				                                    <td>".$recipientArray['Name'][$row_voucher['recipient_id']]."</td>
				                                    <td>".$row_voucher['expiry_date']."</td>
				                                    <td>".$row_voucher['redeemed_on']."</td>
				                                    <td>".$row_voucher['is_active']."</td>
				                                   </tr>";
                            		}
                            		echo $strOffer;
                            	?>
                            	
                            </tbody>
                        </table>
               		</div>
               </div>
    	</div>
   </div>
</div>
<?php 
include_once ('includes/footer.inc.php');
?>