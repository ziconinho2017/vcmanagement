<?php
ini_set("display_errors",1);
include_once("includes/session.inc.php");
set_time_limit(0);
$arrDiscount = array();
if(!isset($_GET['email']) || !isset($_GET['code'])){
	echo "Email or voucher code is blank";
	exit();
}else{
	$rs_discount = $db->query("Select V.voucher_id, V.is_active, O.offer_percentage from `voucher` as V
	INNER JOIN `offers` as O ON O.offer_id = V.offer_id
	INNER JOIN `recipient` as R ON R.recipient_id = V.recipient_id
	Where R.recipient_email = '".$_GET['email']."' and V.voucher_code ='".$_GET['code']."'");
	if($db->num_rows($rs_discount) > 0){
			$row_discount = $db->fetch_assoc($rs_discount);
			if($row_discount['is_active'] == "Y"){
				$arrDiscount['discount'] = $row_discount['offer_percentage'];
				echo json_encode($arrDiscount);
				$db->query("update voucher Set is_active = 'N', redeemed_on='".date('Y-m-d')."' Where voucher_id = '".$row_discount['voucher_id']."'");
			}else{
				echo "Voucher is already redeemed.";
				exit();
			}
	}else{
		echo "Email and Voucher code combination not found.";
		exit();
	}
}
?>
